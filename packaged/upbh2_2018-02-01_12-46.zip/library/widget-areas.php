<?php
/**
 * Register widget areas
 *
 * @package FoundationPress
 * @since FoundationPress 1.0.0
 */

if ( ! function_exists( 'foundationpress_sidebar_widgets' ) ) :
function foundationpress_sidebar_widgets() {
	register_sidebar(array(
		'id' => 'sidebar-widgets',
		'name' => __( 'Sidebar widgets', 'foundationpress' ),
		'description' => __( 'Drag widgets to this sidebar container.', 'foundationpress' ),
		'before_widget' => '<article id="%1$s" class="widget %2$s">',
		'after_widget' => '</article>',
		'before_title' => '<h6>',
		'after_title' => '</h6>',
	));

	register_sidebar(array(
		'id' => 'header-call-number',
		'name' => __( 'Header Call Bar', 'foundationpress' ),
		'description' => __( 'Use a Text Block to put in a phone number', 'foundationpress' ),
		'before_widget' => '<article id="%1$s" class=" widget %2$s">',
		'after_widget' => '</article>',
		'before_title' => '<h6>',
		'after_title' => '</h6>',
	));

	register_sidebar(array(
		'id' => 'blog-right-widgets',
		'name' => __( 'Blog Right widgets', 'foundationpress' ),
		'description' => __( 'Drag Categories and Search to this footer container', 'foundationpress' ),
		'before_widget' => '<article id="%1$s" class=" widget %2$s">',
		'after_widget' => '</article>',
		'before_title' => '<h6>',
		'after_title' => '</h6>',
	));

	register_sidebar(array(
		'id' => 'upper-footer-widgets',
		'name' => __( 'Upper Footer widgets', 'foundationpress' ),
		'description' => __( 'Drag info and image to this footer container', 'foundationpress' ),
		'before_widget' => '<article id="%1$s" class="large-12 columns widget %2$s">',
		'after_widget' => '</article>',
		'before_title' => '<h6>',
		'after_title' => '</h6>',
	));

	register_sidebar(array(
		'id' => 'lower-footer-widgets',
		'name' => __( 'Lower Footer widgets', 'foundationpress' ),
		'description' => __( 'Drag info and image to this footer container', 'foundationpress' ),
		'before_widget' => '<article id="%1$s" class="large-4 small-12 columns widget %2$s">',
		'after_widget' => '</article>',
		'before_title' => '<h6>',
		'after_title' => '</h6>',
	));

	register_sidebar(array(
		'id' => 'lower-social-widgets',
		'name' => __( 'Lower Social widgets', 'foundationpress' ),
		'description' => __( 'Drag info and image to this footer container', 'foundationpress' ),
		'before_widget' => '<article id="%1$s" class=" small-12 columns widget %2$s">',
		'after_widget' => '</article>',
		'before_title' => '<h6>',
		'after_title' => '</h6>',
	));

	register_sidebar(array(
		'id' => 'form-footer-widgets',
		'name' => __( 'Form Footer widgets', 'foundationpress' ),
		'description' => __( 'Drag form widgets to this footer container', 'foundationpress' ),
		'before_widget' => '<div class="row"> <article id="%1$s" class="small-10 small-offset-1 columns widget %2$s">',
		'after_widget' => '</article></div>',
		'before_title' => '<h6>',
		'after_title' => '</h6>',
	));
}

add_action( 'widgets_init', 'foundationpress_sidebar_widgets' );
endif;
